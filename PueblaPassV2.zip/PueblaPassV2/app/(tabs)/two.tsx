import { collection, deleteDoc, doc, limit, onSnapshot, orderBy, query } from 'firebase/firestore';
import React, { useEffect, useState } from 'react';
import { Alert, FlatList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { db } from '../firebase';

// Definición de tipos para que no salgan errores rojos
interface Chofer {
  id: string;
  nombre?: string;
  unidad?: string;
  ruta?: string;
  estado?: string;
}

interface Alerta {
  id: string;
  chofer?: string;
  tipo?: string;
  estatus?: string;
  fecha?: any;
}

export default function MonitorCabina() {
  const [choferes, setChoferes] = useState<Chofer[]>([]);
  const [ultimasAlertas, setUltimasAlertas] = useState<Alerta[]>([]);

  // 1. Escuchar a los choferes en tiempo real
  useEffect(() => {
    const qChoferes = collection(db, "Choferes");
    const unsub = onSnapshot(qChoferes, (snapshot) => {
      const lista = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Chofer[];
      setChoferes(lista);
    });
    return () => unsub();
  }, []);

  // 2. Escuchar incidencias nuevas
  useEffect(() => {
    const qAlertas = query(collection(db, "incidencias"), orderBy("fecha", "desc"), limit(10));
    const unsub = onSnapshot(qAlertas, (snapshot) => {
      const alertasNuevas = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Alerta[];
      setUltimasAlertas(alertasNuevas);
    });
    return () => unsub();
  }, []);

  // 3. Función de resolución con aviso al chofer
  const resolverIncidencia = async (idAlerta: string, nombreChofer: string) => {
    try {
      // Borramos la alerta de tu panel
      await deleteDoc(doc(db, "incidencias", idAlerta));
      
      // Opcional: Podríamos actualizar el estado del chofer a "Normal" automáticamente
      // await updateDoc(doc(db, "Choferes", "Chofer"), { estado: "En ruta" });

      Alert.alert("Cabina", `Incidencia de ${nombreChofer} reportada a administración.`);
    } catch (e) {
      console.error(e);
      Alert.alert("Error", "No se pudo cerrar la incidencia.");
    }
  };

  const renderChofer = ({ item }: { item: Chofer }) => (
    <View style={styles.cardChofer}>
      <View>
        <Text style={styles.nombreChofer}>{item.nombre || "Braulio Hernandez"}</Text>
        <Text style={styles.infoUnidad}>Unidad: {item.unidad || "14"} | {item.ruta || "Línea 4"}</Text>
      </View>
      <View style={[styles.badgeEstado, { backgroundColor: item.estado === 'En ruta' ? '#2ecc71' : '#f39c12' }]}>
        <Text style={styles.textoEstado}>{item.estado?.toUpperCase() || "SIN ESTADO"}</Text>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.tituloHeader}>TORRE DE CONTROL</Text>
        <Text style={styles.subtituloHeader}>Operadora: FER MARIN</Text>
      </View>

      <Text style={styles.seccionTitulo}>MONITOREO DE UNIDADES</Text>
      <FlatList
        data={choferes}
        renderItem={renderChofer}
        keyExtractor={item => item.id}
        style={styles.lista}
      />

      <View style={styles.contenedorAlertas}>
        <Text style={styles.tituloAlertas}>🚨 ALERTAS PENDIENTES</Text>
        {ultimasAlertas.length === 0 ? (
          <Text style={{color: 'white', opacity: 0.5, textAlign: 'center', marginTop: 20}}>Sin novedades en la ruta</Text>
        ) : (
          ultimasAlertas.map((alerta) => (
            <View key={alerta.id} style={styles.alertaItem}>
              <View style={{flex: 1}}>
                <Text style={styles.alertaTexto}>
                  <Text style={{fontWeight: 'bold'}}>{alerta.chofer || "Braulio"}:</Text> {alerta.tipo || "Incidencia"}
                </Text>
              </View>
              <TouchableOpacity 
                style={styles.btnResolver} 
                onPress={() => resolverIncidencia(alerta.id, alerta.chofer || "Chofer")}
              >
                <Text style={styles.btnResolverTexto}>LISTO</Text>
              </TouchableOpacity>
            </View>
          ))
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0F0F0F' },
  header: { backgroundColor: '#9E1C1F', padding: 25, paddingTop: 50 },
  tituloHeader: { color: 'white', fontSize: 22, fontWeight: 'bold', textAlign: 'center' },
  subtituloHeader: { color: 'white', textAlign: 'center', opacity: 0.8 },
  seccionTitulo: { color: '#888', padding: 15, fontSize: 12, fontWeight: 'bold' },
  lista: { flex: 1 },
  cardChofer: { 
    backgroundColor: '#1E1E1E', 
    marginHorizontal: 15, 
    marginBottom: 10, 
    padding: 15, 
    borderRadius: 12, 
    flexDirection: 'row', 
    justifyContent: 'space-between',
    borderLeftWidth: 4,
    borderLeftColor: '#9E1C1F'
  },
  nombreChofer: { color: 'white', fontSize: 16, fontWeight: 'bold' },
  infoUnidad: { color: '#888', fontSize: 12 },
  badgeEstado: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10, height: 25 },
  textoEstado: { color: 'white', fontSize: 10, fontWeight: 'bold' },
  contenedorAlertas: { backgroundColor: '#B22222', padding: 20, borderTopLeftRadius: 30, borderTopRightRadius: 30, minHeight: 200 },
  tituloAlertas: { color: 'white', fontWeight: 'bold', marginBottom: 15 },
  alertaItem: { backgroundColor: 'rgba(255,255,255,0.2)', padding: 15, borderRadius: 10, marginBottom: 10, flexDirection: 'row', alignItems: 'center' },
  alertaTexto: { color: 'white', fontSize: 14 },
  btnResolver: { backgroundColor: 'white', padding: 10, borderRadius: 8 },
  btnResolverTexto: { color: '#B22222', fontWeight: 'bold', fontSize: 12 }
});