import { addDoc, collection, onSnapshot, serverTimestamp } from 'firebase/firestore';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, FlatList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { db } from './firebase';

// Definimos bien qué es un Chofer para que TypeScript no se queje
interface Chofer {
  id: string;
  nombre: string;
  ruta: string;
  unidad: string;
  estado: string;
}

export default function NotificadorInteligente() {
  const [choferes, setChoferes] = useState<Chofer[]>([]);
  const [choferSeleccionado, setChoferSeleccionado] = useState<Chofer | null>(null);
  const [cargando, setCargando] = useState(true);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "Choferes"), (snapshot) => {
      const lista = snapshot.docs.map(doc => ({ 
        id: doc.id, 
        ...doc.data() 
      })) as Chofer[];
      
      // Filtramos para que veas a los que están trabajando o tienen problemas
      const activos = lista.filter(c => 
        c.estado?.toLowerCase() === "en ruta" || c.estado?.toLowerCase() === "incidencia"
      );
      
      setChoferes(activos);
      setCargando(false);
    });
    return () => unsub();
  }, []);

  const enviarAlertaRapida = async (motivo: string) => {
    if (!choferSeleccionado) return;

    try {
      await addDoc(collection(db, "Avisos"), {
        fecha: serverTimestamp(),
        mensaje: `⚠️ La ${choferSeleccionado.ruta} reporta: ${motivo}.`,
        motivo: motivo,
        ruta: choferSeleccionado.ruta,
        tipo: "Retraso",
        emisor: "FER MARIN"
      });

      Alert.alert("¡Enviado!", "Los usuarios ya pueden ver el aviso.");
      setChoferSeleccionado(null);
    } catch (e) {
      Alert.alert("Error", "No se pudo publicar el aviso.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.tituloHeader}>CENTRAL DE DESPACHO</Text>
      <Text style={styles.label}>Toca un chofer para reportar:</Text>
      
      {cargando ? (
        <ActivityIndicator size="large" color="#9E1C1F" />
      ) : (
        <FlatList
          data={choferes}
          horizontal
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <TouchableOpacity 
              style={[styles.cardChofer, choferSeleccionado?.id === item.id && styles.cardSeleccionada]}
              onPress={() => setChoferSeleccionado(item)}
            >
              <Text style={styles.emoji}>{item.estado === 'Incidencia' ? '🚨' : '🚌'}</Text>
              <Text style={styles.nombreChofer}>{item.nombre}</Text>
              <Text style={styles.infoRuta}>{item.ruta}</Text>
            </TouchableOpacity>
          )}
        />
      )}

      {choferSeleccionado && (
        <View style={styles.panelAcciones}>
          <Text style={styles.labelAccion}>Aviso rápido para {choferSeleccionado.nombre}:</Text>
          <View style={styles.gridBotones}>
            <TouchableOpacity style={styles.btnAlerta} onPress={() => enviarAlertaRapida("Tráfico")}>
              <Text style={styles.btnTexto}>🚗 Tráfico</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.btnAlerta} onPress={() => enviarAlertaRapida("Accidente")}>
              <Text style={styles.btnTexto}>⚠️ Accidente</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.btnAlerta, {backgroundColor: '#555'}]} onPress={() => setChoferSeleccionado(null)}>
              <Text style={styles.btnTexto}>Cancelar</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F5F5F5', padding: 20, paddingTop: 60 },
  tituloHeader: { fontSize: 22, fontWeight: 'bold', color: '#9E1C1F', textAlign: 'center', marginBottom: 20 },
  label: { fontSize: 14, color: '#666', marginBottom: 15, fontWeight: '600' },
  cardChofer: { backgroundColor: 'white', padding: 15, borderRadius: 15, marginRight: 12, width: 130, alignItems: 'center', elevation: 4, borderWidth: 2, borderColor: 'transparent' },
  cardSeleccionada: { borderColor: '#9E1C1F', backgroundColor: '#FFF0F0' },
  emoji: { fontSize: 32, marginBottom: 5 },
  nombreChofer: { fontWeight: 'bold', textAlign: 'center', fontSize: 12 },
  infoRuta: { color: '#888', fontSize: 10 },
  panelAcciones: { marginTop: 40, backgroundColor: 'white', padding: 20, borderRadius: 25, elevation: 10 },
  labelAccion: { fontWeight: 'bold', marginBottom: 20, textAlign: 'center', fontSize: 16 },
  gridBotones: { flexDirection: 'row', justifyContent: 'space-between', flexWrap: 'wrap' },
  btnAlerta: { backgroundColor: '#9E1C1F', padding: 15, borderRadius: 12, width: '48%', marginBottom: 10, alignItems: 'center' },
  btnTexto: { color: 'white', fontWeight: 'bold', fontSize: 13 }
});