import { useRouter } from 'expo-router';
import { doc, getDoc } from 'firebase/firestore';
import React, { useState } from 'react';
import { ImageBackground, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { db } from '../firebase';

const fondoImg = require('../../assets/images/fondo.png');

export default function LoginPuebla() {
    const [id, setId] = useState('');
    const router = useRouter(); 

    const manejarEntrada = async () => {
        const idLimpio = id.trim();

        if (!idLimpio) {
            alert("Por favor escribe: operador_001");
            return;
        }

        try {
            const docRef = doc(db, "Operadores", idLimpio);
            const docSnap = await getDoc(docRef);

            if (docSnap.exists()) {
                const datos = docSnap.data();

                alert("¡ÉXITO! Bienvenido " + datos.Nombre);

                // 🔥 AQUÍ CAMBIAMOS RUTA (SIN TABS)
                router.replace('/dashboard'); 

            } else {
                alert("El ID no existe en Firebase");
            }
        } catch (e) {
            console.error("Error:", e);
            alert("Error de conexión");
        }
    };

    return (
        <ImageBackground source={fondoImg} style={styles.background}>
            <View style={styles.overlay}>
                <View style={styles.card}>
                    <Text style={styles.pueblaText}>
                        Puebla<Text style={styles.passText}>Pass</Text>
                    </Text>

                    <View style={styles.linea} />

                    <TextInput
                        style={styles.input}
                        placeholder="operador_001"
                        onChangeText={setId}
                        value={id}
                        autoCapitalize="none"
                    />

                    <TouchableOpacity style={styles.boton} onPress={manejarEntrada}>
                        <Text style={styles.textoBoton}>INGRESAR</Text>
                    </TouchableOpacity>
                </View>
            </View>
        </ImageBackground>
    );
}

const styles = StyleSheet.create({
    background: { flex: 1 },
    overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.3)', justifyContent: 'center', alignItems: 'center' },
    card: { backgroundColor: 'white', padding: 40, borderRadius: 30, width: '90%', maxWidth: 350, alignItems: 'center' },
    pueblaText: { fontSize: 35, fontWeight: 'bold', color: '#9E1C1F' },
    passText: { fontWeight: '300' },
    linea: { width: 50, height: 4, backgroundColor: '#9E1C1F', marginVertical: 20 },
    input: { width: '100%', height: 50, backgroundColor: '#f5f5f5', borderRadius: 10, paddingHorizontal: 15, marginBottom: 20 },
    boton: { width: '100%', height: 50, backgroundColor: '#9E1C1F', borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
    textoBoton: { color: 'white', fontWeight: 'bold' }
});