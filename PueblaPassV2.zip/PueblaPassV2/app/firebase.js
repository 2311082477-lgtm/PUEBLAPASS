import { getApp, getApps, initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyAAdUoLttr4B1UeJfpa6Gw9eqbk3LkHcvY",
  authDomain: "pueblas-pass.firebaseapp.com",
  projectId: "pueblas-pass",
  storageBucket: "pueblas-pass.firebasestorage.app",
  messagingSenderId: "697864026646",
  appId: "1:697864026646:web:0d7924b7ba8d9ea57f1337"
};

// Truco para que no falle en Web
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const db = getFirestore(app);
