const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// Permite que Metro reconozca los módulos de Firebase
config.resolver.sourceExts.push('mjs');

module.exports = config;